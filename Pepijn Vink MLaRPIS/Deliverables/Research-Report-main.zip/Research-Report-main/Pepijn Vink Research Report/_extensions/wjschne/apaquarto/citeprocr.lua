function Pandoc (doc)
  return pandoc.utils.citeproc(doc)
end


