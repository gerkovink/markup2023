# my-reproducible manuscript

<!-- badges: start -->
<!-- badges: end -->

The goal of my-reproducible-manuscript is to finish the exercise of markuplang 2023.

# Author
Min-Wen Yang

#The Date of Creation
14/01/2024

