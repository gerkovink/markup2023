
# my-reproducible-manuscript

<!-- badges: start -->
<!-- badges: end -->

The goal of my-reproducible-manuscript is to produce a quarto document about:
1. Penguins data from `palmerpenguins` package
2. Plot of penguin species
3. Evaluate `do_addition` source code

The aim of boulesteix-et-al-simulation-study is to re-run a reproducible code from boulesteix et al's simulation study.

