# Personal Portfolio
This is a personal portfolio generated using the Quarto Website and hosted by GitHub. You can use this template repository for personal use. 
In order to create a personal website, you can follow this step:
1. Create a repository on GitHub
2. Create a new Quarto Website project on RStudio
3. Edit all Quarto documents in RStudio and publish it
4. Or you can simply use this template and change it to your details
