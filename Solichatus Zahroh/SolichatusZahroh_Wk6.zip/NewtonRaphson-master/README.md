## Newton Raphson Optimisation

The logregNewtonRaphson function performs the Newton-Raphson optimisation to obtain the mle estimates for coefficients in a logistic regression model.
To test the function, you can use the heartdata as an input, where dependent variable is `chd` and the rest variables are independent variables.
