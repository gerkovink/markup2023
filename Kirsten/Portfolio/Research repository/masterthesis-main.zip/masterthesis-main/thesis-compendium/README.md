# thesis-compendium

<!-- badges: start -->
<!-- badges: end -->

This is a reproducible repository that conforms to open science standards containing documents for my master's thesis.

Kirsten van Kessel 
15-01-2024

