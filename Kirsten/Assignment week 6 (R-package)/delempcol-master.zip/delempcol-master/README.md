delempcol
With delempcol you can delete columns in your dataset that only exist of NA values at once. 
