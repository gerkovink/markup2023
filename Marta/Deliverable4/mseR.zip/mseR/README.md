#mseR
A package to compute Mean squared error.
